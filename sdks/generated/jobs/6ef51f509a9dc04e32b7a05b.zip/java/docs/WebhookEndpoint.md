

# WebhookEndpoint


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**createdAt** | **OffsetDateTime** |  |  [optional] |
|**id** | **UUID** |  |  [optional] |
|**isActive** | **Boolean** |  |  [optional] |
|**url** | **URI** |  |  [optional] |



