

# APIKeyInfo


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**expiresAt** | **OffsetDateTime** |  |  [optional] |
|**id** | **UUID** |  |  [optional] |
|**keyPrefix** | **String** |  |  [optional] |
|**lastUsedAt** | **OffsetDateTime** |  |  [optional] |
|**name** | **String** |  |  [optional] |



