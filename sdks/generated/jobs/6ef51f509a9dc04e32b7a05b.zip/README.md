# Aura Java SDK (generated)

- Agent ID: 8ef7c207-b47a-4a3b-99ce-b705b18095ff
- Organization ID: f1c1c0b6-f562-4958-ae7b-517b0f69398f
- Backend: http://localhost:8081

Next steps:
1. Install per-language dependencies.
2. Export AURA_API_KEY with a valid key.
3. Call the verify endpoint using this client.
