# Aura Java SDK (generated)

- Agent ID: da984264-6fba-4cf4-a535-0b1085f910aa
- Organization ID: 0840c417-9c65-436c-9a45-5e9cf94ffb05
- Backend: http://localhost:18081

Next steps:
1. Install per-language dependencies.
2. Export AURA_API_KEY with a valid key.
3. Call the verify endpoint using this client.
