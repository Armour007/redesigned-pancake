

# AuthAttestPostRequest


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**agentId** | **UUID** |  |  [optional] |
|**orgId** | **UUID** |  |  [optional] |



