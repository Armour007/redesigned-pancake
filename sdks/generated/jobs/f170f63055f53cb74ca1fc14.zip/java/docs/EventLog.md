

# EventLog


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**agentId** | **UUID** |  |  [optional] |
|**apiKeyPrefixUsed** | **String** |  |  [optional] |
|**decision** | **String** |  |  [optional] |
|**decisionReason** | **String** |  |  [optional] |
|**eventType** | **String** |  |  [optional] |
|**id** | **UUID** |  |  [optional] |
|**organizationId** | **UUID** |  |  [optional] |
|**statusCode** | **Integer** |  |  [optional] |
|**timestamp** | **OffsetDateTime** |  |  [optional] |



