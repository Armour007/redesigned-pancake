

# VerifyRequest


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**action** | **String** |  |  [optional] |
|**agentId** | **UUID** |  |  [optional] |
|**organizationId** | **UUID** |  |  [optional] |
|**requestContext** | **Map&lt;String, Object&gt;** |  |  [optional] |
|**resource** | **String** |  |  [optional] |



