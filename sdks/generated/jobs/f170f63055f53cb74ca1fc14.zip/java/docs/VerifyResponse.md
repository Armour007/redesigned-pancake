

# VerifyResponse


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**decision** | [**DecisionEnum**](#DecisionEnum) |  |  [optional] |
|**reason** | **String** |  |  [optional] |



## Enum: DecisionEnum

| Name | Value |
|---- | -----|
| ALLOWED | &quot;ALLOWED&quot; |
| DENIED | &quot;DENIED&quot; |



