# Aura Java SDK (generated)

- Agent ID: 1a4b9001-eac3-488d-8b07-8f3e9086a7e2
- Organization ID: 89a86a46-d5e6-4d47-a462-958810efce10
- Backend: http://localhost:8081

Next steps:
1. Install per-language dependencies.
2. Export AURA_API_KEY with a valid key.
3. Call the verify endpoint using this client.
