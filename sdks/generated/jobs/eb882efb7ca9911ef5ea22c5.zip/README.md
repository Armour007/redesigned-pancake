# Aura Java SDK (generated)

- Agent ID: e77b95a1-15e3-4e15-adee-40b398b9f3d3
- Organization ID: c2e852df-0c94-47a6-a6d6-55ffe54d4e1b
- Backend: http://localhost:8081

Next steps:
1. Install per-language dependencies.
2. Export AURA_API_KEY with a valid key.
3. Call the verify endpoint using this client.
