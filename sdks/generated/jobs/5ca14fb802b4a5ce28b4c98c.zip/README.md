# Aura Java SDK (generated)

- Agent ID: 48e69ccb-c522-4446-b016-e62c8b12065d
- Organization ID: c723fdee-12e8-4e22-8b1c-c6c5e36f8512
- Backend: http://localhost:8081

Next steps:
1. Install per-language dependencies.
2. Export AURA_API_KEY with a valid key.
3. Call the verify endpoint using this client.
