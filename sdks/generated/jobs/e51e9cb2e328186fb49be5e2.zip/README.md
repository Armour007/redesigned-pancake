# Aura Java SDK (generated)

- Agent ID: e340358a-4394-48ae-8fff-977187128a4f
- Organization ID: b4c93be5-7994-4a2e-8c28-7d6630e6017e
- Backend: http://localhost:8081

Next steps:
1. Install per-language dependencies.
2. Export AURA_API_KEY with a valid key.
3. Call the verify endpoint using this client.
