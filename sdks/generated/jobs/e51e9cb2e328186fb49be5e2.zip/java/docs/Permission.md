

# Permission


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**action** | **String** |  |  [optional] |
|**createdAt** | **OffsetDateTime** |  |  [optional] |
|**id** | **UUID** |  |  [optional] |
|**isActive** | **Boolean** |  |  [optional] |
|**resource** | **String** |  |  [optional] |



