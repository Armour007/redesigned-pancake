# Aura Java SDK (generated)

- Agent ID: 94c9a1a0-a36d-4925-bd5a-57809c11641a
- Organization ID: 86ca9360-5326-48a8-83e8-3f9851391583
- Backend: http://localhost:8081

Next steps:
1. Install per-language dependencies.
2. Export AURA_API_KEY with a valid key.
3. Call the verify endpoint using this client.
