# Aura Java SDK (generated)

- Agent ID: 132a372f-4821-4a50-acb7-868f0d8c65a5
- Organization ID: af7327a7-85b0-42ad-9264-8788bbb6a37f
- Backend: http://localhost:8081

Next steps:
1. Install per-language dependencies.
2. Export AURA_API_KEY with a valid key.
3. Call the verify endpoint using this client.
