# Aura Java SDK (generated)

- Agent ID: f2538304-b629-4062-bbfe-83d1b4e21bf0
- Organization ID: f107cdb8-1577-47f5-9645-545310a619bc
- Backend: http://localhost:8081

Next steps:
1. Install per-language dependencies.
2. Export AURA_API_KEY with a valid key.
3. Call the verify endpoint using this client.
