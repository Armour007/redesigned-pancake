# Aura Java SDK (generated)

- Agent ID: ddbefae8-265b-4ff9-808f-2dd8d6d3dd21
- Organization ID: 88715817-b3fb-4470-a503-45ca1e62238d
- Backend: http://localhost:8081

Next steps:
1. Install per-language dependencies.
2. Export AURA_API_KEY with a valid key.
3. Call the verify endpoint using this client.
