# Aura Java SDK (generated)

- Agent ID: ae95129a-2696-4fc2-a6fb-a4d74b669f0b
- Organization ID: 54bb810f-efe7-4897-9fa4-530d0e253fdb
- Backend: http://localhost:18081

Next steps:
1. Install per-language dependencies.
2. Export AURA_API_KEY with a valid key.
3. Call the verify endpoint using this client.
