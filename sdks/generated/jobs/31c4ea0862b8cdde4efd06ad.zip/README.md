# Aura Java SDK (generated)

- Agent ID: 486a7163-0929-449d-b85b-5dc72800378a
- Organization ID: bef74b89-2228-47dc-89f5-11a70855b179
- Backend: http://localhost:18081

Next steps:
1. Install per-language dependencies.
2. Export AURA_API_KEY with a valid key.
3. Call the verify endpoint using this client.
